def test_only():
    return True
