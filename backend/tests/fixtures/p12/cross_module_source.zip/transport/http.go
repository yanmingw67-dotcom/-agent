package transport

type Sender interface { Send(text string) error }
type Robot struct {}
func (r Robot) Send(text string) error { return nil }
func Format(text string) string { return text }
