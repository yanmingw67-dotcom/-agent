class RobotSender:
    def send(self, event):
        return format_event(event)

def format_event(event):
    return str(event)
