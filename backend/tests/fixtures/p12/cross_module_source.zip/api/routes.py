from notify.sender import RobotSender

def handle_alert(event):
    sender = RobotSender()
    return sender.send(event)
