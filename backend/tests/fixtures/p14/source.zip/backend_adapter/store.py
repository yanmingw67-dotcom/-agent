def reserve_once(store, tenant, event_id):
    return store.put_if_absent((tenant, event_id), True)
