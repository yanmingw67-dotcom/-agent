def read_clock(clock):
    return clock()
