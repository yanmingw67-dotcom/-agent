def format_id(event):
    return str(event["id"])
