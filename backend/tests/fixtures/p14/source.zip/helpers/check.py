def valid(event):
    return "id" in event
