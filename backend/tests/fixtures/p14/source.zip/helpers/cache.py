def cache_value(cache, key, value):
    cache[key] = value
    return value
