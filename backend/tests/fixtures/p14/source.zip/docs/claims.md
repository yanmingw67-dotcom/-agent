# Unverified
Persistent storage and exactly-once delivery are not demonstrated.
