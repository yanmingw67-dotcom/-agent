from api.routes import register_routes
from callbacks.registry import subscribe
from callbacks.audit import on_audit
from config.defaults import DEFAULTS

def install(router, sink):
    subscribe(on_audit)
    return register_routes(router, DEFAULTS, sink)
