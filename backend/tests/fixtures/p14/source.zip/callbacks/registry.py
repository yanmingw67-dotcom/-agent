CALLBACKS = []

def subscribe(callback):
    CALLBACKS.append(callback)

def notify_callbacks(event):
    for callback in CALLBACKS:
        callback(event)
