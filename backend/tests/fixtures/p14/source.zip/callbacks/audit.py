def on_audit(event):
    return {"audit_id": event["id"]}
