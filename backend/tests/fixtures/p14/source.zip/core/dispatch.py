from callbacks.registry import notify_callbacks

def dispatch(event, settings, sink):
    if not settings["enabled"]:
        return {"skipped": True}
    if event["severity"] < settings["minimum"]:
        return {"filtered": True}
    sink.append(event)
    notify_callbacks(event)
    return {"accepted": True}
