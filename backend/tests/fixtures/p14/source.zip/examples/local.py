def run_local(dispatch, event, settings):
    return dispatch(event, settings, [])
