def retry_once(send):
    try:
        return send()
    except TimeoutError:
        return send()
