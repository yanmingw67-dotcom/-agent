from core.dispatch import dispatch

def register_routes(router, settings, sink):
    def receive(event):
        return dispatch(event, settings, sink)
    router.add_route("/events", receive)
    return receive
