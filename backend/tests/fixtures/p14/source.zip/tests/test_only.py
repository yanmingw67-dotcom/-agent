def only_test(fake):
    return fake.post("https://example.invalid", {})
