DEFAULTS = {"enabled": True, "minimum": 3}
