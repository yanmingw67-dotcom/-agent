from notify.sender import notify

def handle_event(event, settings, transport):
    if not settings["enabled"]:
        return {"skipped": True}
    if event["severity"] < settings["minimum_severity"]:
        return {"filtered": True}
    return notify(settings["platform"], settings["robot_id"], [event], transport)
