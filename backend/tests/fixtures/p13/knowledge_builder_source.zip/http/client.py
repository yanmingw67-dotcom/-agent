class Transport:
    def __init__(self, session):
        self.session = session

    def post(self, url, body, headers):
        return self.session.post(url, data=body, headers=headers, timeout=5)

def unused_retry(send, attempts=3):
    for attempt in range(attempts):
        try:
            return send()
        except TimeoutError:
            if attempt + 1 == attempts:
                raise
# 此独立函数未接入事件入口，不能据此确认产品自动重试。
