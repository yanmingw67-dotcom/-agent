import json
PLATFORMS = {"feishu": "https://open.feishu.cn", "ding": "https://oapi.dingtalk.com"}

def payload(platform, events):
    text = "\n".join(str(e["message"]) for e in events)
    if platform == "feishu":
        return {"msg_type": "text", "content": {"text": text}}
    if platform == "ding":
        return {"msgtype": "text", "text": {"content": text}}
    raise ValueError("unsupported platform")

def notify(platform, token, events, transport):
    endpoint = PLATFORMS[platform] + "/robot/send/" + token
    return transport.post(endpoint, json.dumps(payload(platform, events)),
                          headers={"Content-Type": "application/json"})
