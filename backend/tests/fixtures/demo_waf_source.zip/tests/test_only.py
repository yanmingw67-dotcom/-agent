def test_only_helper():
    return '仅测试代码，不是产品能力'
