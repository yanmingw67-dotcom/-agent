package httphelper

import "net/http"

// 人工样例：独立工具函数不证明产品存在完整通知链路。
func StatusOK(response *http.Response) bool {
    return response.StatusCode >= 200 && response.StatusCode < 300
}
